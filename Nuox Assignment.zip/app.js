
const express = require('express');
const mongoose = require('mongoose');
const app = express();
const userRouter = require('./src/routers/userRouter');

app.use(express.json());

mongoose.set('strictQuery', true);

// Connect to MongoDB (you need to set up a MongoDB instance and replace the connection string)
mongoose.connect('mongodb+srv://manihari:Mani1234@cluster0.gtc54hl.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });
app.use('/',userRouter); 

// Start the server
app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});