
const User = require('../models/userschema');

const userController = {
  createUser: async (req, res) => {
    try {
      const newUser = new User(req.body);
      const savedUser = await newUser.save();
      res.status(201).json(savedUser);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  updateUser: async (req, res) => {
    try {
      const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.status(200).json(updatedUser);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  updateUsers: async (req, res) => {
    try {
      const updatedUsers = await User.updateMany(req.body);
      res.status(200).json(updatedUsers);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  removeUser: async (req, res) => {
    try {
      await User.findByIdAndRemove(req.params.id);
      res.status(204).json({message:"successfully deleted"});
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  findUsersByCity: async (req, res) => {
    try {
        console.log(req.params);
      const usersInCity = await User.find({ 'Address.city': req.params.cityName});
      res.status(200).json(usersInCity);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  findUsersByState: async (req, res) => {
    try {
      const usersInState = await User.find({ 'Address.state': req.params.stateName});
      res.status(200).json(usersInState);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
};

module.exports = userController;