const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware');

// Insert a user
router.post('/user',authMiddleware,  userController.createUser);

// Update a user
router.put('/user/:id', authMiddleware, userController.updateUser);
//update many
router.put('/user',authMiddleware,userController.updateUsers)
// Delete a user
router.delete('/user/:id',authMiddleware, userController.removeUser);

// Find users
router.get('/user/city/:cityName',authMiddleware, userController.findUsersByCity);
router.get('/user/state/:stateName',authMiddleware,  userController.findUsersByState);

module.exports = router;