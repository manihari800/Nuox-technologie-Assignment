const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  // Get token from the request headers or other sources
  const token = jwt.sign("userID","secret_key");

  // Check if token exists
  if (!token) {
    return res.status(401).json({ message: 'Authorization denied, token not found' });
  }

  try {
    // Verify the token

    const decoded = jwt.verify(token, "secret_key"); // Change 'your_secret_key' to your actual secret key
    // Attach the user information to the request object
    req.user = decoded.id;
    next();
  } catch (error) {
    return res.status(401).json({ message: error.message });
  }
};

module.exports = authMiddleware;